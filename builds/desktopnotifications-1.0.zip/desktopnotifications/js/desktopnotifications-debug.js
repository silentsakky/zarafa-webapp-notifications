Ext.namespace('Zarafa.plugins.desktopnotifications');

/**
 * @class Zarafa.plugins.desktopnotifications.ABOUT
 * @extends String
 *
 * The copyright string holding the copyright notice for the Zarafa Desktop Notifications Plugin.
 */
Zarafa.plugins.desktopnotifications.ABOUT = ""
	+ "<p>Copyright (C) 2013  Saket Patel &lt;silentsakky@gmail.com&gt;</p>"

	+ "<p>This program is free software: you can redistribute it and/or modify "
	+ "it under the terms of the GNU Affero General Public License as "
	+ "published by the Free Software Foundation, either version 3 of the "
	+ "License, or (at your option) any later version.</p>"

	+ "<p>This program is distributed in the hope that it will be useful, "
	+ "but WITHOUT ANY WARRANTY; without even the implied warranty of "
	+ "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the "
	+ "GNU Affero General Public License for more details.</p>"

	+ "<p>You should have received a copy of the GNU Affero General Public License "
	+ "along with this program. If not, see <a href=\"http://www.gnu.org/licenses/\" target=\"_blank\">http://www.gnu.org/licenses/</a>.</p>";Ext.namespace('Zarafa.plugins.desktopnotifications.js');

/**
 * @class Zarafa.plugins.desktopnotifications.js.DesktopNotification
 * @singleton
 *
 * Singleton class to provide a wrapper for HTML5 desktop notifications feature
 */
Zarafa.plugins.desktopnotifications.js.DesktopNotification = (function() {
	var notificationAPI = window.webkitNotifications || window.Notification;
	var PERMISSION = ['granted', 'default', 'denied'];

	return {
		/**
		 * Check if browser supports notifications API
		 * @return {Boolean} true if browser supports desktop notifications else false
		 */
		supports : function()
		{
			if(notificationAPI) {
				return true;
			}

			return false;
		},

		/**
		 * Check if browser has permissions to show notifications
		 * @return {Boolean} true if permissions are granted to show desktop notifications else false
		 */
		hasPermission : function()
		{
			if(!this.supports()) {
				alert('Browser doesn\'t support notifications');
			}

			var permission = 'default';
			if(Ext.isFunction(notificationAPI.checkPermission)) {
				permission = PERMISSION[notificationAPI.checkPermission()];
			} else if (Ext.isFunction(notificationAPI.permissionLevel)) {
				permission = notificationAPI.permissionLevel();
			} else if (notificationAPI.permission) {
				permission = notificationAPI.permission;
			}

			if(permission === 'granted') {
				return true;
			}

			return false;
		},

		/**
		 * Ask for permissions to show notifications
		 * In chrome this function will only work when you call it based on some user action
		 * like click of a button
		 * @param {Function} callback callback function that will be called after user has
		 * granted/rejected permission request
		 */
		authorize : function(callback)
		{
			if(!this.supports()) {
				alert('Browser doesn\'t support notifications');
			}

			callback = Ext.isFunction(callback) ? callback : Ext.emptyFn;

			if (Ext.isFunction(notificationAPI.requestPermission)) {
				notificationAPI.requestPermission(callback);
			}
		},

		/**
		 * Function will show a desktop notification
		 * @param {String} title title to use when showing desktop notifications
		 * @param {Object} options object containing below key value pairs to provide extra information
		 * for the desktop notifications
		 * 		- icon : icon to show in desktop notifications
		 * 		- body : message to display
		 *		- tag : tag to group same type of notifications so multiple notifications
		 *				will not be showed multiple times
		 */
		notify : function(title, options)
		{
			if(!this.supports()) {
				alert('Browser doesn\'t support notifications');
			}

			if(!this.hasPermission()) {
				alert('Permission is denied to show desktop notifications');
			}

			var notification;
// autoclose, handlers
			if(Ext.isFunction(notificationAPI.createNotification)) {
				notification = notificationAPI.createNotification(options.icon, title, options.body);
				notification.show();
			} else {
				notification = new notificationAPI(title, {
					icon : options.icon,
					body : options.body,
					tag : options.tag
				});
			}
		}
	};
})();
Ext.namespace('Zarafa.plugins.desktopnotifications');

/**
 * @class Zarafa.plugins.desktopnotifications.DesktopNotificationsPlugin
 * @extends Zarafa.core.Plugin
 * This class is used for adding files from the users's Dropbox folder
 * to his emails as attachments
 */
Zarafa.plugins.desktopnotifications.DesktopNotificationsPlugin = Ext.extend(Zarafa.core.Plugin, {
	/**
	 * initialises insertion point for plugin
	 * @protected
	 */
	initPlugin : function()
	{
		Zarafa.plugins.desktopnotifications.DesktopNotificationsPlugin.superclass.initPlugin.apply(this, arguments);

		this.registerInsertionPoint('context.settings.category.plugins', this.createSettingsWidget, this);
	},

	/**
	 * Return the instance of {@link Zarafa.plugins.pimfolder.PimPluginSettingsWidget}.
	 *
	 * @return {Zarafa.plugins.pimfolder.PimPluginSettingswidget} An instance of the settings widget
	 * @private
	 */
	createSettingsWidget : function()
	{
		return {
			xtype : 'zarafa.notificationsettingswidget',
			plugin : this
		};
	}
});

Zarafa.onReady(function() {
	container.registerPlugin(new Zarafa.core.PluginMetaData({
		name : 'desktopnotifications',
		displayName : _('Desktop Notifications Plugin'),
		about : Zarafa.plugins.desktopnotifications.ABOUT,
		pluginConstructor : Zarafa.plugins.desktopnotifications.DesktopNotificationsPlugin
	}));
});
Ext.namespace('Zarafa.plugins.desktopnotifications.js');

/**
 * @class Zarafa.plugins.desktopnotifications.js.DesktopNotifier
 * @extends Zarafa.core.ui.notifier.NotifyPlugin
 *
 * A plugin for notification plugin to show desktop notifications instead of normal in browser
 * notifications for actions like new mail, reminder etc.
 */
Zarafa.plugins.desktopnotifications.js.DesktopNotifier = Ext.extend(Zarafa.core.ui.notifier.NotifyPlugin, {
	/**
	 * @constructor
	 * @param {Object} config Configuration object
	 */
	constructor : function(config)
	{
		config = config || {};

		Zarafa.plugins.desktopnotifications.js.DesktopNotifier.superclass.constructor.call(this, config);
	},

	/**
	 * Notify the user with a message.
	 *
	 * The category can be either  "error", "warning", "info" or "debug", or a subtype thereof (e.g. "info.newmail").
	 *
	 * @param {String} category The category which applies to the notification.
	 * @param {String} title The title which must be shown in the message.
	 * @param {String} message The message which should be displayed.
	 * @param {Object} config Configuration object which can be applied to the notifier
	 * This object can contain keys like:
	 * - autoclose: Auto close notification after sometime
	 * @return {Mixed} A reference to the message which was created, this can be used
	 * as value for 'reference' in the config argument.
	 */
	notify : function(category, title, message, config)
	{
		Zarafa.plugins.desktopnotifications.js.DesktopNotification.notify(title, {
			tag : category,
			body : message,
			icon : 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAAAeCAMAAADthUvBAAADAFBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAgIHBgsQFBYjHiAjHh8jHiAjHiAjHh8jHh8jHh8jHh8jHh8jHh8jHh8jHh8jHh8jHh8jHh8jHh8jHh8jHh8jHh8jHh8jHh8jHh8jHh8jHh8jHh8jHh8jHh8jHyAjHyAjHyAjHx8iHx8iHx8jHx8jHx8jHx8jHx8jHx8jHx8iHyIiHyIhHyIiHyIiHyEiHyEjHx8jHyAjHx8jHx8jHx8jHx8jHx8jHx8jHx8jHx8jHx8jHx8jHx8jHx8jHx8jHx8jHx8jHx8jHx8jHx8jHx8jHx8jHx8jHx8iICIhICIiICMiICMhISYgIicdIyggJCkbJSoeJS0hJSshJSodJzQaKzsaLEEWMk8TOF8UOF8RPGoQPnARPnEPQHQPQHcQQXoQQXoQQXoQQXoQQXoQQXoQQXoQQXoQQXoQQXkQQXgQQXoQQXoQQXoQQXoPQXgQQXoPQXkQQXoQQXoQQXoPQXoQQXoQQXoQQXoQQXoQQXoQQnoQQnoQQnoQQnoQQnoQQnr////+/v7+/v78/Pz8/Pz6+vr6+vr4+Pj4+Pj39/f19fX19fXz8/Pz8/Px8fHx8fHv7+/u7u7u7u7s7Ozs7Ozq6urq6uro6Ojn5+fn5+fl5eXl5eXj4+Pi4uLi4uLg4ODg4ODe3t7e3t7c3Nzb29vb29vZ2dnZ2dnX19fW1tbW1tbU1NTU1NTS0tLR0dHR0dHPz8/Nzc3Nzc3MzMzMzMzKysrJycnJycnHx8fHx8fFxcXExMTExMTCwsLBwcHBwcG/v7+/v7+9vb28vLy8vLy6urq5ubm5ubm3t7e2tra2tra0tLSysrKysrKxsbGxsbGvr6+urq6urq6srKyrq6urq6upqamenZ2Uk5OCgYFTT1AQQXoQQXo3MzQlISIjHyAjHx8jHx8jHx8jHx8jHx8jHx8jHx8jHx8jHx8jHx8jHx/avajJAAAAlXRSTlMAAAAAAAAAAAAAAAAAAAAAAAAAAAABAwUzN15oe32FlpudoaSmqKmssLS5vsHFx97g5OdaYGRvc3eCiIuNkZQZHR8jKC44OsvO0NLV2dvo6uvu7/Lz9fb4+vv9/v47PGIWahMIEAg4CwyKNaMzMNgxNvM8Qunu19/k9Pn8/v7823yVhE25Vshjv65ojWync13OX2HD1ad3sKQAAAAGdEVYdFRpdGxlAKju0icAAAAHdEVYdEF1dGhvcgCprsxIAAAADHRFWHREZXNjcmlwdGlvbgATCSEjAAAACnRFWHRDb3B5cmlnaHQArA/MOgAAAAd0RVh0RS1tYWlsAH0Im9UAAAAEdEVYdFVSTAB4o9MPAAAC0UlEQVRIx+2Wb0/aUBTG9/p+gV4KamKiImMMJUacG0sWpoLiABUmpLSkmtBXmmmy7Z1/FhOzrLj2ftTnA+zcW6BoMghZXHzhSaC9tLk/zvOcc9oX7D/Ei2fIU4d4Q3Eprh8JEp5eCeGfPC6k070TYqJUrNmlSmIiSMcnxnd3glS0NGrbm5NAul9Iq3PPF3enjNlhjIA4eKVNJJcnxK3vnVyQYC5jOfQjNQKShj6RJ64QXzue7xJL0A98Jogy3vydYTdgTQK5dr8JceyTJZRIWG4tFG2m8YwhVTmySLoNzmzeisjNNQ5wi84szu3xkLOuuCGprikL0XXDctOWDvN2bp9Ea+Zs9g56K42ouaxUtFhKydnQkk2gnvwwBnIqpEjiTPohtRpA5tFmrFR0zNgn5Ng6Vpexpa+XHdOsYofFFoDczDSvza1NpVB5PxLyUwQQT37fHIcQEwWSQdXPBmraGvZSRm+t7SLCLICuW8qXJKZHQqg7yAnhe+6PoBV7EG23bgxuKiOSBW3cjzhtGkCCiD4swwcQEWRCnzNxOdQ4W8gGJ7ztzFaQaaPXd9ZK29nBfAjhmdUFpMdkcueR774cKcchREdVHT9ukr3VGsw24irBxc9kdBVzfcjKtqqA3ZGQX+cXV26XKe/DxrHKdS6P+WrDyWukuZmlfamQC0hEOGsPIFlUsi0eGQMhM2Sb+6rVB5B4T6wFrAfG9iBRFOV6ALHQlH/GGAMhz2UWF8If6k69b2QaLXko9SHzeCvXuT5ER0GuM+Mg/q1Q1TU0Ani11psYO2rTGBBdU5CcysQ4xGIAMam4acIUURmTiasgw3MmgdezKpwpHDiryf0CYlMKYjSwHY0fpPCyJ1cVCT27VcLhaE+Er0wZPIN/M1YfTGHHaaBZ3IhhOoAwfQ9Itw2SMzC+VaapU9L20fmXF4kj4/5Dw87z+9cjGZKWW8/vXU8d8ge2Pc74+0t4dQAAAABJRU5ErkJggg=='
		});

		Zarafa.plugins.desktopnotifications.js.DesktopNotifier.superclass.notify.apply(this, arguments);
	}
});

Zarafa.onReady(function() {
	container.getNotifier().registerPlugin('desktopnotifier', new Zarafa.plugins.desktopnotifications.js.DesktopNotifier());
});
Ext.namespace('Zarafa.plugins.desktopnotifications.js.settings');

/**
 * @class Zarafa.plugins.desktopnotifications.js.settings.NotificationSettingsWidget
 * @extends Zarafa.settings.ui.SettingsWidget
 * @xtype zarafa.notificationsettingswidget
 *
 * The {@link Zarafa.settings.ui.SettingsWidget widget} for
 * configuring the settings of the plugin
 */
Zarafa.plugins.desktopnotifications.js.settings.NotificationSettingsWidget = Ext.extend(Zarafa.settings.ui.SettingsWidget, {

	/**
	 * @cfg {Zarafa.plugins.desktopnotifications.js.DesktopNotificationsPlugin} plugin The plugin which has registered this
	 * settings widget.
	 */
	plugin : undefined,

	/**
	 * Settings model instance which will be used to get current settings
	 * @property
	 * @type Zarafa.settings.SettingsModel
	 */
	model : undefined,

	/**
	 * @constructor
	 * @param {Object} config Configuration object
	 */
	constructor : function(config)
	{
		config = config || {};

		Ext.applyIf(config, {
			title : _('Desktop Notifications Settings Plugin'),
			xtype: 'panel',
			height : 125,
			layout : {
				type : 'vbox',
				align : 'left',
				pack  : 'start'
			},
			items : this.createPanelItems()
		});

		Zarafa.plugins.desktopnotifications.js.settings.NotificationSettingsWidget.superclass.constructor.call(this, config);
	},

	/**
	 * Function will return object which will be used to create items for this settings widget
	 * @return {Array} Array containing configuration objects of child items
	 */
	createPanelItems : function()
	{
		return [{
			xtype : 'displayfield',
			value : _('For enabling desktop notifications we need permissions from browser.'),
			fieldClass : 'x-form-display-field zarafa-settings-widget-extrainfo'
		}, {
			xtype : 'button',
			text : _('Request Permissions'),
			handler : this.requestPermission,
			scope : this,
			ref : 'requestPermissionBtn'
		}];
	},

	/**
	 * Function will be used to get permission from user to show desktop notifications
	 * @FIXME move code of changing setting to some other part
	 */
	requestPermission : function()
	{
		Zarafa.plugins.desktopnotifications.js.DesktopNotification.authorize(function(perm) {
			// chrome doesn't give us current permission level, so default to granted if permission level is passed
			var permission = 'granted';
			if(perm) {
				permission = perm;
			}

			if(permission === 'granted') {
				// update ui
				this.update(this.model);

				// update settings for new mail notification
				container.getSettingsModel().set('zarafa/v1/main/notifier/info/newmail/value', 'desktopnotifier');
			}
		}.createDelegate(this));
	},

	/**
	 * Update the view with the new values of the settings
	 * model. Called when opening the settings widget or when a new
	 * folder is selected.
	 *
	 * @param {Zarafa.settings.SettingsModel} settingsModel The settings to display.
	 */
	update : function(settingsModel)
	{
		this.model = settingsModel;

		var disabled = false;
		if(Zarafa.plugins.desktopnotifications.js.DesktopNotification.hasPermission()) {
			disabled = true;
		}

		this.requestPermissionBtn.setDisabled(disabled);
	}
});

Ext.reg('zarafa.notificationsettingswidget', Zarafa.plugins.desktopnotifications.js.settings.NotificationSettingsWidget);
